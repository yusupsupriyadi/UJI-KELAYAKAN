$credentials = [
    		'username' => $request->username,
    		'password' => $request->password
    	];

$user = DB::table('user')->where('username', $request->username)->first();

    	if (Auth::guard($user->)->attempt($credentials, $request->remember)) {
    		return redirect('/home');
    	}