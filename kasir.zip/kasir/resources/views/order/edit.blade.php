@extends('layouts.master')

@section('content')
<div class="main">
		<div class="main-content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Inputs</h3>
								</div>
								<div class="panel-body">
									<form action="/order/{{$order->id_order}}/update" method="POST">
                            {{csrf_field()}}
                            
                            <div class="form-group">
							    <label for="exampleInputEmail1">ID ORDER</label>
							    <input name="id_order" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="NIS">
                              </div>
                              
							  <div class="form-group">
							    <label for="exampleInputEmail1">NO MEJA</label>
							    <input name="no_meja" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama">
							  </div>
							  
							  <div class="form-group">
							    <label for="exampleInputEmail1">TANGGAL</label>
							    <input name="tanggal" type="date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama">
							  </div>

							  <div class="form-group">
							    <label for="exampleInputEmail1">ID USER</label>
							    <input name="id_user" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama">
							  </div>
							  
							  <div class="form-group">
								<label for="exampleFromControlSelect1">MAKANAN</label>
								<select name="nama_masakan" class="form-control" id="exampleFromControlSelect1">
								@foreach($masakan as $masakan)
								<option value="{{$masakan->nama_masakan}}" @if($order->nama_masakan == $masakan->nama_masakan)selected @endif>{{$masakan->nama_masakan}}</option>
								@endforeach
							</select>
							</div>

							  <div class="form-group">
							    <label for="exampleInputEmail1">KETERANGAN</label>
							    <input name="keterangan" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama">
							  </div>
							  
							  <div class="form-group">
							    <label for="exampleInputEmail1">STATUS ORDER</label>
							    <input name="status_order" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama">
                              </div>
                              
                             
							  
							  <button type="submit" class="btn btn-warning">UPDATE</button>
				        </form>
								</div>
							</div>
					</div>
				</div>
			</div>
		</div>
	</div>
@stop


@section('content1')

		
			<h1>EDIT DATA LEVEL </h1>
			@if(session('sukses'))
				<div class="alert alert-success" role="alert">
					{{session('sukses')}}
				</div>
			@endif
			<div class="row">
				<div class="col-lg-12">
			 
					</div>
				</div>
			</div>
				
@endsection