<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<nav>
					<ul class="nav">
						<li><a href="/" class="active"><i class="lnr lnr-home"></i> <span>Dashboard</span></a></li>
						<li><a href="/order" class=""><i class="lnr lnr-user"></i> <span>ORDER</span></a></li>
						
						<li><a href="/transaksi" class=""><i class=" fa fa-paper-plane-o"></i> <span>TRANSAKSI</span></a></li>
						<li><a href="/masakan" class=""><i class="fa fa-home"></i> <span>MASAKANNYA</span></a></li>
						<li><a href="/pengguna" class=""><i class="fa fa-home"></i> <span>PENGGUNA</span></a></li>
						<li><a href="/level" class=""><i class="fa fa-home"></i> <span>LEVEL</span></a></li>
						
					</ul>
				</nav>
			</div>
		</div>