@extends('layouts.master')

@section('content')
	<div class="main">
		<div class="main-content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="col-md-6">
							<!-- TABLE HOVER -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Masakan</h3>
									<div class="right">
									</button>
									<a href="/siswa/export" class="btn btn-sm btn-primary">Excel</a>
									<button type="button" class="btn" data-toggle="modal" data-target="#exampleModalLong"><i class="lnr lnr-plus-circle"></i></button>
								</div>
							</div>
						</div>
								<div class="panel-body">
									<table class="table table-hover">
										<thead>
											<tr>
												<th>ID Masakan</th>
												<th>NAMA MASAKAN</th>
												<th>HARGA</th>
												<th>STATUS MAKANAN</th>
												
											</tr>
										</thead>
										<tbody>
											@foreach ($data_masakan as $masakan)
											<tr>
												<td>{{$masakan->id_masakan}}</td>
												<td>{{$masakan->nama_masakan}}</td>
												<td>{{$masakan->harga}}</td>
												<td>{{$masakan->status_masakan}}</td>
												<td>
													<a href="/masakan/{{$masakan->id_masakan}}/edit" class = "btn btn-warning btn-sm">Edit</a>
													<a href="/masakan/{{$masakan->id_masakan}}/delete" class="btn btn-danger btn-sm" onclick="return confirm('Yakin Mau diHapus?')">Hapus</a>
												</td>
												
											</tr>
											@endforeach
										</tbody>
									</table>
								</div>
							</div>
							<!-- END TABLE HOVER -->
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<!-- MODAL -->
<div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
				  <div class="modal-dialog" role="document">
				    <div class="modal-content">
				      <div class="modal-header">
				        <h5 class="modal-title" id="exampleModalLongTitle">FROM DATA MASAKAN</h5>
				        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
				          <span aria-hidden="true">&times;</span>
				        </button>
				      </div>
				      <div class="modal-body">
				        <form action="/masakan/create" method="POST">
				        	{{csrf_field()}}
							  <div class="form-group">
							    <label for="exampleInputEmail1">ID MASAKAN</label>
							    <input name="id_masakan" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="NIS">
                              </div>
                              
							  <div class="form-group">
							    <label for="exampleInputEmail1">NAMA MASAKAN</label>
							    <input name="nama_masakan" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama">
                              </div>
                              
                              <div class="form-group">
							    <label for="exampleInputEmail1">HARGA</label>
							    <input name="harga" type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama">
							  </div>
                              
                              <div class="form-group">
							    <label for="exampleInputEmail1">STATUS</label>
							    <input name="status_masakan" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama">
							  </div>
							  
							  
							  
							  
							  
						
				      </div>
				      <div class="modal-footer">
				        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				        <button type="submit" class="btn btn-primary">Simpan</button>
				        </form>
				      </div>
				    </div>
				  </div>
				
@stop	