@extends('layouts.master')

@section('content')
<div class="main">
		<div class="main-content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Inputs</h3>
								</div>
								<div class="panel-body">
									<form action="/detail_order/{{$detail_order->id_detail_order}}/update" method="POST">
                            {{csrf_field()}}
                            
                            <div class="form-group">
							    <label for="exampleInputEmail1">ID DETAIL ORDER</label>
							    <input name="id_detail_order" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="NIS" value= "{{$detail_order->id_detail_order}}">
                              </div>
                              
							  <div class="form-group">
							    <label for="exampleInputEmail1">ID ORDER</label>
							    <input name="id_order" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama" value= "{{$detail_order->id_order}}">
							  </div>
							  
							  <div class="form-group">
							    <label for="exampleInputEmail1">ID MASAKAN</label>
							    <input name="id_masakan" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama" value= "{{$detail_order->id_masakan}}">
							  </div>
							  
							  <div class="form-group">
							    <label for="exampleInputEmail1">KETERANGAN</label>
							    <input name="keterangan" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama" value= "{{$detail_order->keterangan}}">
							  </div>
							  
							  <div class="form-group">
							    <label for="exampleInputEmail1">STATUS DETAIL ORDER</label>
							    <input name="status_detail_order" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama" value= "{{$detail_order->status_detail_order}}">
                              </div>
                              
                             
							  
							  <button type="submit" class="btn btn-warning">UPDATE</button>
				        </form>
								</div>
							</div>
					</div>
				</div>
			</div>
		</div>
	</div>
@stop


@section('content1')

		
			<h1>EDIT DATA LEVEL </h1>
			@if(session('sukses'))
				<div class="alert alert-success" role="alert">
					{{session('sukses')}}
				</div>
			@endif
			<div class="row">
				<div class="col-lg-12">
			 
					</div>
				</div>
			</div>
				
@endsection