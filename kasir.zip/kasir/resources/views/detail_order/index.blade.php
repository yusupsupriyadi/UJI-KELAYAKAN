@extends('layouts.master')

@section('content')
	<div class="main">
		<div class="main-content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="col-md-6">
							<!-- TABLE HOVER -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">LEVEL</h3>
									<div class="right">
									</button>
									<a href="/siswa/export" class="btn btn-sm btn-primary">Excel</a>
									<button type="button" class="btn" data-toggle="modal" data-target="#exampleModalLong"><i class="lnr lnr-plus-circle"></i></button>
								</div>
							</div>
						</div>
								<div class="panel-body">
									<table class="table table-hover">
										<thead>
											<tr>
												<th>ID DETAIL ORDER</th>
												<th>ID ORDER</th>
												<th>ID MASAKAN </th>
												<th>ID ORDER</th>
												<th>KETERANGAN</th>
												<th>STATUS DETAIL ORDER</th>
												
											</tr>
										</thead>
										<tbody>
											@foreach ($data_detail_order as $detail_order)
											<tr>
												<td>{{$detail_order->id_detail_order}}</td>
												<td>{{$detail_order->id_order}}</td>
												<td>{{$detail_order->id_masakan}}</td>
												<td>{{$detail_order->keterangan}}</td>
												<td>{{$detail_order->status_detail_order}}</td>

												<td>
													<a href="/detail_order/{{$detail_order->id_detail_order}}/edit" class = "btn btn-warning btn-sm">Edit</a>
													<a href="/detail_order/{{$detail_order->id_detail_order}}/delete" class="btn btn-danger btn-sm" onclick="return confirm('Yakin Mau diHapus?')">Hapus</a>
                                                </td>
                                                    
											</tr>
											@endforeach
										</tbody>
									</table>
								</div>
							</div>
							<!-- END TABLE HOVER -->
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<!-- MODAL -->
<div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
				  <div class="modal-dialog" role="document">
				    <div class="modal-content">
				      <div class="modal-header">
				        <h5 class="modal-title" id="exampleModalLongTitle">FROM DATA LEVEL</h5>
				        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
				          <span aria-hidden="true">&times;</span>
				        </button>
				      </div>
				      <div class="modal-body">
				        <form action="/detail_order/create" method="POST">
				        	{{csrf_field()}}
							  <div class="form-group">
							    <label for="exampleInputEmail1">ID DETAIL ORDER</label>
							    <input name="id_detail_order" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="NIS">
                              </div>
                              
							  <div class="form-group">
								<label for="exampleFromControlSelect1">id order</label>
								<select name="id_order" class="form-control" id="exampleFromControlSelect1">
								@foreach($order as $order)
								<option value="{{$order->id_order}}">{{$order->id_order}}</option>
								@endforeach
							</select>
							</div>
							  
							  <div class="form-group">
								<label for="exampleFromControlSelect1">id masakan</label>
								<select name="id_masakan" class="form-control" id="exampleFromControlSelect1">
								@foreach($masakan as $masakan)
								<option value="{{$masakan->id_masakan}}">{{$masakan->id_masakan}}</option>
								@endforeach
							</select>
							</div>
							  
							  <div class="form-group">
							    <label for="exampleInputEmail1">KETERANGAN</label>
							    <input name="keterangan" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama">
							  </div>
							  
							  <div class="form-group">
							    <label for="exampleInputEmail1">STATUS DETAIL ORDER</label>
							    <input name="status_detail_order" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama">
                              </div>
                              
                              
				      </div>
				      <div class="modal-footer">
				        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				        <button type="submit" class="btn btn-primary">Simpan</button>
				        </form>
				      </div>
				    </div>
				  </div>
				
@stop	