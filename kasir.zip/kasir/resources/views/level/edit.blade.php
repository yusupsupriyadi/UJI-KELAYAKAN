@extends('layouts.master')

@section('content')
<div class="main">
		<div class="main-content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Inputs</h3>
								</div>
								<div class="panel-body">
									<form action="/level/{{$level->id_level}}/update" method="POST">
                            {{csrf_field()}}
                            
                            <div class="form-group">
							    <label for="exampleInputEmail1">ID LEVEL</label>
							    <input name="id_level" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="NIS" value= "{{$level->id_level}}">
                              </div>
                              
							  <div class="form-group">
							    <label for="exampleInputEmail1">NAMA LEVEL</label>
							    <input name="nama_level" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama" value= "{{$level->nama_level}}" >
                              </div>
                              
                             
							  
							  <button type="submit" class="btn btn-warning">UPDATE</button>
				        </form>
								</div>
							</div>
					</div>
				</div>
			</div>
		</div>
	</div>
@stop


@section('content1')

		
			<h1>EDIT DATA LEVEL </h1>
			@if(session('sukses'))
				<div class="alert alert-success" role="alert">
					{{session('sukses')}}
				</div>
			@endif
			<div class="row">
				<div class="col-lg-12">
			 
					</div>
				</div>
			</div>
				
@endsection