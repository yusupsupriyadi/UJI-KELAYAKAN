<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $primaryKey='id_order';
    protected $table ='order';
    protected $fillable = ['id_order','nama','no_meja','tanggal','nama_masakan','keterangan','status_order'];
}
