<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function index(Request $request)
    {
        $data_order=\App\Order::all();
        $masakan=\App\Masakan::all();
        $pengguna=\App\Pengguna::all();
        return view('order.index',['data_order' => $data_order,'masakan' => $masakan,'pengguna' => $pengguna]);
    }

    public function create(Request $request)
    {
    	\App\Order::create($request->all());
    	return redirect('/order')-> with('sukses','data berhasil disimpan');
    }

    public function edit($id_order)
    {
        $order = \App\Order::find($id_order);
        $masakan=\App\Masakan::all();
        $pengguna=\App\Pengguna::all();
    	return view('order/edit',['order' => $order,'masakan' => $masakan,'pengguna' => $pengguna]);
    }

    public function update(Request $request,$id_order)
    {
        $order = \App\Order::find($id_order);
        $order->update($request->all());
        return redirect('/order')->with('sukses','Data berhasil diupdate');
    }

    public function delete($id_order)
    {
        $order = \App\Order::find($id_order);
        $order->delete();
        return redirect('/order')->with('sukses','Data berhasil dihapus ');
    }
}
