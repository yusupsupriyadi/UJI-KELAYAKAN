<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MasakanController extends Controller
{
    public function index(Request $request)
    {
        $data_masakan=\App\Masakan::all();
        return view('masakan.index',['data_masakan' => $data_masakan]);
    }

    public function create(Request $request)
    {
    	\App\Masakan::create($request->all());
    	return redirect('/masakan')-> with('sukses','data berhasil disimpan');
    }

    public function edit($id_masakan)
    {
    	$masakan = \App\Masakan::find($id_masakan);
    	return view('masakan/edit',['masakan' => $masakan]);
    }

    public function update(Request $request ,$id_masakan)
    {
        $masakan = \App\Masakan::find($id_masakan);
        $masakan->update($request->all());
        return redirect('/masakan')->with('sukses','Data berhasil diupdate');
    }

    public function delete($id_masakan)
    {
        $masakan = \App\Masakan::find($id_masakan);
        $masakan->delete();
        return redirect('/masakan')->with('sukses','Data berhasil dihapus ');
    }
}
