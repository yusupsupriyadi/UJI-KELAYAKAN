<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Detail_orderController extends Controller
{
    public function index(Request $request)
    {
        $data_detail_order=\App\Detail_order::all();
        $order=\App\Order::all();
        $masakan=\App\Masakan::all();
        return view('detail_order.index',['data_detail_order' => $data_detail_order,'order' => $order,'masakan' => $masakan]);
    }

    public function create(Request $request)
    {
    	\App\Detail_order::create($request->all());
    	return redirect('/detail_order')-> with('sukses','data berhasil disimpan');
    }

    public function edit($id_detail_order)
    {
        $detail_order = \App\Detail_order::find($id_detail_order);
        $order=\App\Order::all();
        $masakan=\App\Masakan::all();
    	return view('detail_order/edit',['detail_order' => $detail_order,'order' => $order,'masakan' => $masakan]);
    }

    public function update(Request $request,$id_detail_order)
    {
        $detail_order = \App\Detail_order::find($id_detail_order);
        $detail_order->update($request->all());
        return redirect('/detail_order')->with('sukses','Data berhasil diupdate');
    }

    public function delete($id_detail_order)
    {
        $detail_order = \App\Detail_order::find($id_detail_order);
        $detail_order->delete();
        return redirect('/detail_order')->with('sukses','Data berhasil dihapus ');
    }
}
