<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LevelController extends Controller
{
    public function index(Request $request)
    {
        $data_level=\App\Level::all();
        return view('level.index',['data_level' => $data_level]);
    }

    public function create(Request $request)
    {
    	\App\Level::create($request->all());
    	return redirect('/level')-> with('sukses','data berhasil disimpan');
    }

    public function edit($id_level)
    {
    	$level = \App\Level::find($id_level);
    	return view('level/edit',['level' => $level]);
    }

    public function update(Request $request,$id_level)
    {
        $level = \App\Level::find($id_level);
        $level->update($request->all());
        return redirect('/level')->with('sukses','Data berhasil diupdate');
    }

    public function delete($id_level)
    {
        $level = \App\Level::find($id_level);
        $level->delete();
        return redirect('/level')->with('sukses','Data berhasil dihapus ');
    }
}
