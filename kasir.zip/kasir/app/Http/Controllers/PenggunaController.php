<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PenggunaController extends Controller
{
    public function index(Request $request)
    {
        $data_pengguna=\App\Pengguna::all();
        $level=\App\Level::all();
        return view('pengguna.index',['data_pengguna' => $data_pengguna,'level' => $level]);
    }

    public function create(Request $request)
    {
    	\App\Pengguna::create($request->all());
    	return redirect('/pengguna')-> with('sukses','data berhasil disimpan');
    }

    public function edit($id)
    {
        $pengguna = \App\Pengguna::find($id);
        $level=\App\Pengguna::all();
    	return view('pengguna/edit',['pengguna' => $pengguna,'level' => $level]);
    }

    public function update(Request $request,$id)
    {
        $pengguna = \App\Pengguna::find($id);
        $pengguna->update($request->all());
        return redirect('/pengguna')->with('sukses','Data berhasil diupdate');
    }

    public function delete($id)
    {
        $pengguna = \App\Pengguna::find($id);
        $pengguna->delete();
        return redirect('/pengguna')->with('sukses','Data berhasil dihapus ');
    }
}
