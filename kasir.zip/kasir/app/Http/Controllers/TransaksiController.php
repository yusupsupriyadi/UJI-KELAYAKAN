<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TransaksiController extends Controller
{
    public function index(Request $request)
    {
        $data_transaksi=\App\Transaksi::all();
        $pengguna=\App\Pengguna::all();
        $order=\App\Order::all();
        return view('transaksi.index',['data_transaksi' => $data_transaksi,'pengguna' => $pengguna,'order' => $order]);
    }

    public function create(Request $request)
    {
    	\App\Transaksi::create($request->all());
    	return redirect('/transaksi')-> with('sukses','data berhasil disimpan');
    }

    public function edit($id_transaksi)
    {
        $transaksi = \App\Transaksi::find($id_transaksi);
        $pengguna=\App\Pengguna::all();
        $order=\App\Order::all();
    	return view('transaksi/edit',['transaksi' => $transaksi,'pengguna' => $pengguna,'order' => $order]);
    }

    public function update(Request $request,$id_transaksi)
    {
        $transaksi = \App\Transaksi::find($id_transaksi);
        $transaksi->update($request->all());
        return redirect('/transaksi')->with('sukses','Data berhasil diupdate');
    }

    public function delete($id_transaksi)
    {
        $transaksi = \App\Transaksi::find($id_transaksi);
        $transaksi->delete();
        return redirect('/transaksi')->with('sukses','Data berhasil dihapus ');
    }
}
