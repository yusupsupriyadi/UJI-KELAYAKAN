<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pengguna extends Model
{
    protected $primaryKey='id';
    protected $table ='Pengguna';
    protected $fillable = ['nama','nama_level','username','password'];
}
