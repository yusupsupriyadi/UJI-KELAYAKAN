<?php $__env->startSection('content'); ?>
	<div class="main">
		<div class="main-content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="col-md-6">
							<!-- TABLE HOVER -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">LEVEL</h3>
									<div class="right">
									</button>
									<a href="/siswa/export" class="btn btn-sm btn-primary">Excel</a>
									<button type="button" class="btn" data-toggle="modal" data-target="#exampleModalLong"><i class="lnr lnr-plus-circle"></i></button>
								</div>
							</div>
						</div>
								<div class="panel-body">
									<table class="table table-hover">
										<thead>
											<tr>
												<th>ID LEVEL</th>
												<th>NAMA LEVEL</th>
												
											</tr>
										</thead>
										<tbody>
											<?php $__currentLoopData = $data_level; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td><?php echo e($level->id_level); ?></td>
												<td><?php echo e($level->nama_level); ?></td>
												<td>
													<a href="/level/<?php echo e($level->id_level); ?>/edit" class = "btn btn-warning btn-sm">Edit</a>
													<a href="/level/<?php echo e($level->id_level); ?>/delete" class="btn btn-danger btn-sm" onclick="return confirm('Yakin Mau diHapus?')">Hapus</a>
                                                </td>
                                                    
											</tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</tbody>
									</table>
								</div>
							</div>
							<!-- END TABLE HOVER -->
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<!-- MODAL -->
<div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
				  <div class="modal-dialog" role="document">
				    <div class="modal-content">
				      <div class="modal-header">
				        <h5 class="modal-title" id="exampleModalLongTitle">FROM DATA LEVEL</h5>
				        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
				          <span aria-hidden="true">&times;</span>
				        </button>
				      </div>
				      <div class="modal-body">
				        <form action="/level/create" method="POST">
				        	<?php echo e(csrf_field()); ?>

							  <div class="form-group">
							    <label for="exampleInputEmail1">ID LEVEL</label>
							    <input name="id_level" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="NIS">
                              </div>
                              
							  <div class="form-group">
							    <label for="exampleInputEmail1">NAMA LEVEL</label>
							    <input name="nama_level" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama">
                              </div>
                              
                              
				      </div>
				      <div class="modal-footer">
				        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				        <button type="submit" class="btn btn-primary">Simpan</button>
				        </form>
				      </div>
				    </div>
				  </div>
				
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kasir\resources\views/level/index.blade.php ENDPATH**/ ?>