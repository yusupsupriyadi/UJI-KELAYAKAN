<?php $__env->startSection('content'); ?>
<div class="main">
		<div class="main-content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Inputs</h3>
								</div>
								<div class="panel-body">
									<form action="/level/<?php echo e($level->id_level); ?>/update" method="POST">
                            <?php echo e(csrf_field()); ?>

                            
                            <div class="form-group">
							    <label for="exampleInputEmail1">ID LEVEL</label>
							    <input name="id_level" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="NIS" value= "<?php echo e($level->id_level); ?>">
                              </div>
                              
							  <div class="form-group">
							    <label for="exampleInputEmail1">NAMA LEVEL</label>
							    <input name="nama_level" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama" value= "<?php echo e($level->nama_level); ?>" >
                              </div>
                              
                             
							  
							  <button type="submit" class="btn btn-warning">UPDATE</button>
				        </form>
								</div>
							</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content1'); ?>

		
			<h1>EDIT DATA LEVEL </h1>
			<?php if(session('sukses')): ?>
				<div class="alert alert-success" role="alert">
					<?php echo e(session('sukses')); ?>

				</div>
			<?php endif; ?>
			<div class="row">
				<div class="col-lg-12">
			 
					</div>
				</div>
			</div>
				
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kasir\resources\views/level/edit.blade.php ENDPATH**/ ?>