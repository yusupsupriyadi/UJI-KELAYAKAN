<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('admin/home', 'HomeController@adminHome')->name('admin.home')->middleware('is_admin');

Route::get('/masakan','MasakanController@index');
Route::post('/masakan/create','MasakanController@create');
Route::get('/masakan/{id}/edit','MasakanController@edit');
Route::post('/masakan/{id}/update','MasakanController@update');
Route::get('/masakan/{id}/delete','MasakanController@delete');

Route::get('/level','LevelController@index');
Route::post('/level/create','LevelController@create');
Route::get('/level/{id_level}/edit','LevelController@edit');
Route::post('/level/{id_level}/update','LevelController@update');
Route::get('/level/{id_level}/delete','LevelController@delete');

Route::get('/detail_order','Detail_orderController@index');
Route::post('/detail_order/create','Detail_orderController@create');
Route::get('/detail_order/{id_detail_order}/edit','Detail_orderController@edit');
Route::post('/detail_order/{id_detail_order}/update','Detail_orderController@update');
Route::get('/detail_order/{id_detail_order}/delete','Detail_orderlController@delete');

Route::get('/order','OrderController@index');
Route::post('/order/create','OrderController@create');
Route::get('/order/{id_order}/edit','OrderController@edit');
Route::post('/order/{id_order}/update','OrderController@update');
Route::get('/order/{id_order}/delete','OrderlController@delete');

Route::get('/transaksi','TransaksiController@index');
Route::post('/transaksi/create','TransaksiController@create');
Route::get('/transaksi/{id_transaksi}/edit','TransaksiController@edit');
Route::post('/transaksi/{id_transaksi}/update','TransaksiController@update');
Route::get('/transaksi/{id_transaksi}/delete','TransaksiController@delete');

Route::get('/pengguna','PenggunaController@index');
Route::post('/pengguna/create','PenggunaController@create');
Route::get('/pengguna/{id}/edit','PenggunaController@edit');
Route::post('/pengguna/{id}/update','PenggunaController@update');
Route::get('/pengguna/{id}/delete','PenggunaController@delete');
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
